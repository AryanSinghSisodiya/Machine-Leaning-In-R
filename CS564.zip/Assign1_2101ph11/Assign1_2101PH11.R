# STEP 1

# Load dataset
data(mtcars)
# Get the dimensions (rows and columns)
dim(mtcars)

# STEP 2

# Descriptive statistics
summary(mtcars)

# STEP 3

# Convert specific variables to factors
mtcars$cyl <- as.factor(mtcars$cyl)
mtcars$vs <- as.factor(mtcars$vs)
mtcars$am <- as.factor(mtcars$am)
mtcars$gear <- as.factor(mtcars$gear)
mtcars$carb <- as.factor(mtcars$carb)

# STEP 4

# Plot mpg vs other variables
pairs(mpg ~ ., data = mtcars)

# STEP 5

# Compute correlation matrix (excluding factor variables)
cor_matrix <- cor(mtcars[, sapply(mtcars, is.numeric)])
cor_matrix

# STEP 6

# Find correlation of mpg with other variables
cor_mpg <- cor(mtcars$mpg, mtcars[, sapply(mtcars, is.numeric)])
# Sort the correlations and get the top 3 (excluding mpg itself)
sort(cor_mpg, decreasing = TRUE)[2:4]

# STEP 7

# Fit models for the top 3 predictors
model_hp <- lm(mpg ~ hp, data = mtcars)
model_wt <- lm(mpg ~ wt, data = mtcars)
model_disp <- lm(mpg ~ disp, data = mtcars)

# Get the summary of each model
summary(model_hp)
summary(model_wt)
summary(model_disp)

# Plot mpg vs hp with regression line
par(mfrow = c(1, 3)) # Set up a 1x3 plotting area

# Plot for 'hp'
plot(mtcars$hp, mtcars$mpg, main="mpg vs hp", xlab="hp", ylab="mpg")
abline(model_hp, col="green")

# Plot for 'wt'
plot(mtcars$wt, mtcars$mpg, main="mpg vs wt", xlab="wt", ylab="mpg")
abline(model_wt, col="green")

# Plot for 'disp'
plot(mtcars$disp, mtcars$mpg, main="mpg vs disp", xlab="disp", ylab="mpg")
abline(model_disp, col="green")

# Reset plotting layout to default
par(mfrow = c(1, 1))

# STEP 8

# Fit multiple linear regression model
model_multiple <- lm(mpg ~ hp + wt + disp, data = mtcars)
summary(model_multiple)


# STEP 9

# Create the Observation data frame with model results
Observation <- data.frame(
  Model = c('hp', 'wt', 'disp', 'Multiple'),
  RSE = c(summary(model_hp)$sigma, summary(model_wt)$sigma, summary(model_disp)$sigma, summary(model_multiple)$sigma),
  R2 = c(summary(model_hp)$r.squared, summary(model_wt)$r.squared, summary(model_disp)$r.squared, summary(model_multiple)$r.squared),
  Adjusted_R2 = c(NA, NA, NA, summary(model_multiple)$adj.r.squared),
  F_statistic = c(NA, NA, NA, summary(model_multiple)$fstatistic[1])
)

# View the data frame
print(Observation)



